class Activity {
    [string] $DisplayName
    [string] $Script
    [string[]] $DependsOn
    [string] $ID
}